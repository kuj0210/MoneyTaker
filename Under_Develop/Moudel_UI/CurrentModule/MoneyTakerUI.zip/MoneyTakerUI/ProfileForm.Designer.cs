﻿namespace MoneyTakerUI
{
    partial class ProfileForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProfileForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.ModifyPanel = new System.Windows.Forms.Panel();
            this.SaveInformationBtn = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ModifyTag = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ModifyEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.ModifyPhoneNumber = new System.Windows.Forms.Label();
            this.ModifyName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.UploadBtn = new System.Windows.Forms.Button();
            this.ModifyInformationBtn = new System.Windows.Forms.Button();
            this.ProfileTag = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ProfileEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ProfilePhoneNumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ProfileName = new System.Windows.Forms.TextBox();
            this.JUUserNameLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.ModifyPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.panel1.Controls.Add(this.ModifyPanel);
            this.panel1.Controls.Add(this.UploadBtn);
            this.panel1.Controls.Add(this.ModifyInformationBtn);
            this.panel1.Controls.Add(this.ProfileTag);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.ProfileEmail);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.ProfilePhoneNumber);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ProfileName);
            this.panel1.Controls.Add(this.JUUserNameLabel);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(926, 585);
            this.panel1.TabIndex = 0;
            // 
            // ModifyPanel
            // 
            this.ModifyPanel.Controls.Add(this.SaveInformationBtn);
            this.ModifyPanel.Controls.Add(this.textBox2);
            this.ModifyPanel.Controls.Add(this.textBox1);
            this.ModifyPanel.Controls.Add(this.ModifyTag);
            this.ModifyPanel.Controls.Add(this.label8);
            this.ModifyPanel.Controls.Add(this.label6);
            this.ModifyPanel.Controls.Add(this.label4);
            this.ModifyPanel.Controls.Add(this.ModifyEmail);
            this.ModifyPanel.Controls.Add(this.label5);
            this.ModifyPanel.Controls.Add(this.textBox6);
            this.ModifyPanel.Controls.Add(this.ModifyPhoneNumber);
            this.ModifyPanel.Controls.Add(this.ModifyName);
            this.ModifyPanel.Controls.Add(this.label7);
            this.ModifyPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.ModifyPanel.Location = new System.Drawing.Point(480, 0);
            this.ModifyPanel.Name = "ModifyPanel";
            this.ModifyPanel.Size = new System.Drawing.Size(446, 585);
            this.ModifyPanel.TabIndex = 9;
            this.ModifyPanel.Visible = false;
            // 
            // SaveInformationBtn
            // 
            this.SaveInformationBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.SaveInformationBtn.FlatAppearance.BorderSize = 0;
            this.SaveInformationBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(129)))));
            this.SaveInformationBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.SaveInformationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveInformationBtn.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SaveInformationBtn.ForeColor = System.Drawing.Color.White;
            this.SaveInformationBtn.Location = new System.Drawing.Point(7, 490);
            this.SaveInformationBtn.Name = "SaveInformationBtn";
            this.SaveInformationBtn.Size = new System.Drawing.Size(300, 45);
            this.SaveInformationBtn.TabIndex = 17;
            this.SaveInformationBtn.Text = "Save";
            this.SaveInformationBtn.UseVisualStyleBackColor = false;
            this.SaveInformationBtn.Click += new System.EventHandler(this.SaveInformationBtn_Click);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.textBox2.Location = new System.Drawing.Point(7, 449);
            this.textBox2.MaxLength = 20;
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(300, 23);
            this.textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.textBox1.Location = new System.Drawing.Point(7, 382);
            this.textBox1.MaxLength = 20;
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(300, 23);
            this.textBox1.TabIndex = 9;
            // 
            // ModifyTag
            // 
            this.ModifyTag.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ModifyTag.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ModifyTag.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyTag.Location = new System.Drawing.Point(7, 312);
            this.ModifyTag.MaxLength = 20;
            this.ModifyTag.Name = "ModifyTag";
            this.ModifyTag.Size = new System.Drawing.Size(300, 23);
            this.ModifyTag.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label8.Location = new System.Drawing.Point(2, 418);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 28);
            this.label8.TabIndex = 13;
            this.label8.Text = "Re-Enter PassWord : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label6.Location = new System.Drawing.Point(2, 351);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 28);
            this.label6.TabIndex = 13;
            this.label6.Text = "PassWord : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label4.Location = new System.Drawing.Point(2, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "Tag : ";
            // 
            // ModifyEmail
            // 
            this.ModifyEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ModifyEmail.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ModifyEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyEmail.Location = new System.Drawing.Point(7, 240);
            this.ModifyEmail.MaxLength = 20;
            this.ModifyEmail.Name = "ModifyEmail";
            this.ModifyEmail.Size = new System.Drawing.Size(300, 23);
            this.ModifyEmail.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label5.Location = new System.Drawing.Point(2, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 28);
            this.label5.TabIndex = 14;
            this.label5.Text = "E - mail : ";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.textBox6.Location = new System.Drawing.Point(7, 172);
            this.textBox6.MaxLength = 20;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(300, 23);
            this.textBox6.TabIndex = 11;
            // 
            // ModifyPhoneNumber
            // 
            this.ModifyPhoneNumber.AutoSize = true;
            this.ModifyPhoneNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.ModifyPhoneNumber.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ModifyPhoneNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyPhoneNumber.Location = new System.Drawing.Point(2, 141);
            this.ModifyPhoneNumber.Name = "ModifyPhoneNumber";
            this.ModifyPhoneNumber.Size = new System.Drawing.Size(170, 28);
            this.ModifyPhoneNumber.TabIndex = 15;
            this.ModifyPhoneNumber.Text = "Phone Number : ";
            // 
            // ModifyName
            // 
            this.ModifyName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ModifyName.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ModifyName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyName.Location = new System.Drawing.Point(7, 105);
            this.ModifyName.MaxLength = 20;
            this.ModifyName.Name = "ModifyName";
            this.ModifyName.Size = new System.Drawing.Size(300, 23);
            this.ModifyName.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label7.Location = new System.Drawing.Point(2, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 28);
            this.label7.TabIndex = 16;
            this.label7.Text = "User Name : ";
            // 
            // UploadBtn
            // 
            this.UploadBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.UploadBtn.FlatAppearance.BorderSize = 0;
            this.UploadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(129)))));
            this.UploadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.UploadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UploadBtn.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.UploadBtn.ForeColor = System.Drawing.Color.White;
            this.UploadBtn.Location = new System.Drawing.Point(290, 342);
            this.UploadBtn.Name = "UploadBtn";
            this.UploadBtn.Size = new System.Drawing.Size(73, 37);
            this.UploadBtn.TabIndex = 8;
            this.UploadBtn.Text = "Upload";
            this.UploadBtn.UseVisualStyleBackColor = false;
            // 
            // ModifyInformationBtn
            // 
            this.ModifyInformationBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyInformationBtn.FlatAppearance.BorderSize = 0;
            this.ModifyInformationBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(125)))), ((int)(((byte)(129)))));
            this.ModifyInformationBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ModifyInformationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ModifyInformationBtn.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ModifyInformationBtn.ForeColor = System.Drawing.Color.White;
            this.ModifyInformationBtn.Location = new System.Drawing.Point(487, 370);
            this.ModifyInformationBtn.Name = "ModifyInformationBtn";
            this.ModifyInformationBtn.Size = new System.Drawing.Size(300, 45);
            this.ModifyInformationBtn.TabIndex = 8;
            this.ModifyInformationBtn.Text = "Moidfy Information";
            this.ModifyInformationBtn.UseVisualStyleBackColor = false;
            this.ModifyInformationBtn.Click += new System.EventHandler(this.ModifyInformationBtn_Click);
            // 
            // ProfileTag
            // 
            this.ProfileTag.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProfileTag.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ProfileTag.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ProfileTag.Location = new System.Drawing.Point(487, 312);
            this.ProfileTag.MaxLength = 20;
            this.ProfileTag.Name = "ProfileTag";
            this.ProfileTag.Size = new System.Drawing.Size(300, 23);
            this.ProfileTag.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label3.Location = new System.Drawing.Point(482, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 28);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tag : ";
            // 
            // ProfileEmail
            // 
            this.ProfileEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProfileEmail.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ProfileEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ProfileEmail.Location = new System.Drawing.Point(487, 240);
            this.ProfileEmail.MaxLength = 20;
            this.ProfileEmail.Name = "ProfileEmail";
            this.ProfileEmail.Size = new System.Drawing.Size(300, 23);
            this.ProfileEmail.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label2.Location = new System.Drawing.Point(482, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 28);
            this.label2.TabIndex = 7;
            this.label2.Text = "E - mail : ";
            // 
            // ProfilePhoneNumber
            // 
            this.ProfilePhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProfilePhoneNumber.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ProfilePhoneNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ProfilePhoneNumber.Location = new System.Drawing.Point(487, 172);
            this.ProfilePhoneNumber.MaxLength = 20;
            this.ProfilePhoneNumber.Name = "ProfilePhoneNumber";
            this.ProfilePhoneNumber.Size = new System.Drawing.Size(300, 23);
            this.ProfilePhoneNumber.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.label1.Location = new System.Drawing.Point(482, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 28);
            this.label1.TabIndex = 7;
            this.label1.Text = "Phone Number : ";
            // 
            // ProfileName
            // 
            this.ProfileName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProfileName.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ProfileName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.ProfileName.Location = new System.Drawing.Point(487, 105);
            this.ProfileName.MaxLength = 20;
            this.ProfileName.Name = "ProfileName";
            this.ProfileName.Size = new System.Drawing.Size(300, 23);
            this.ProfileName.TabIndex = 6;
            // 
            // JUUserNameLabel
            // 
            this.JUUserNameLabel.AutoSize = true;
            this.JUUserNameLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.JUUserNameLabel.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.JUUserNameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(94)))), ((int)(((byte)(98)))));
            this.JUUserNameLabel.Location = new System.Drawing.Point(482, 74);
            this.JUUserNameLabel.Name = "JUUserNameLabel";
            this.JUUserNameLabel.Size = new System.Drawing.Size(132, 28);
            this.JUUserNameLabel.TabIndex = 7;
            this.JUUserNameLabel.Text = "User Name : ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(147, 105);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 201);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ProfileForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.ClientSize = new System.Drawing.Size(926, 585);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProfileForm";
            this.Text = "ProfileForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ModifyPanel.ResumeLayout(false);
            this.ModifyPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox ProfileName;
        private System.Windows.Forms.Label JUUserNameLabel;
        private System.Windows.Forms.TextBox ProfileTag;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ProfileEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ProfilePhoneNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel ModifyPanel;
        private System.Windows.Forms.Button SaveInformationBtn;
        private System.Windows.Forms.TextBox ModifyTag;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ModifyEmail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label ModifyPhoneNumber;
        private System.Windows.Forms.TextBox ModifyName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button UploadBtn;
        private System.Windows.Forms.Button ModifyInformationBtn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
    }
}